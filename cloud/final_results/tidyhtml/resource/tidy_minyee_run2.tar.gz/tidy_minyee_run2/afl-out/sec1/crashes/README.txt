Command line used to find this crash:

afl-fuzz -i /home/ubuntu/fyp/FYP/cloud/seeds/html -o /home/ubuntu/fyp/runs/tidy_minyee_run2/afl-out -V 43200 -m none -t 1000 -S sec1 -p explore -- /home/ubuntu/fyp/targets/tidy-build/tidy_parse_string_fuzzer-afl

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 0 B.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please post
to https://github.com/AFLplusplus/AFLplusplus/issues/286 once the issues
 are fixed :)

